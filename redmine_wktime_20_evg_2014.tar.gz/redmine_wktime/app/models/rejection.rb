class Rejection < ActiveRecord::Base
  unloadable
  belongs_to :projects
  belongs_to :users
  belongs_to :users, :foreign_key => :approved_by
end
