class AddWknotesToWktimes < ActiveRecord::Migration
  def change
    add_column :wktimes, :wknotes, :text
  end
end
