class UserUnlockEntry < ActiveRecord::Base
  unloadable
  belongs_to :user
  validates_presence_of :user_id, :comment

  def self.user_lock_status(user_id)
    days = Setting.plugin_redmine_wktime['wktime_nonlog_day'].to_i
    setting_hr= Setting.plugin_redmine_wktime['wktime_nonlog_hr'].to_i
    setting_min = Setting.plugin_redmine_wktime['wktime_nonlog_min'].to_i
    current_time = Time.now
    expire_time = Time.new(current_time.year, current_time.month, current_time.day,setting_hr,setting_min,1, "+05:30")
    deadline_date = (Date.today-days.to_i)
    lock_status = UserUnlockEntry.where(:user_id=>user_id)
    if lock_status.present?
      lock_status_expire_time = lock_status.last.expire_time.to_datetime
      if lock_status_expire_time <= expire_time
        lock_status.delete_all
      end
    end
    user = User.where(:id=> user_id)
    rec = TimeEntry.where(:user_id=> user_id, :spent_on => (deadline_date-1).strftime('%Y-%m-%d').to_s)
    @rec_status=''
    date = deadline_date-1
    (1..30).each do |x|
      @rec=TimeEntry.where(:user_id=> user_id, :spent_on => date.to_date)
      if !@rec.present?
        @rec_status=[]
        break
      else
        @rec_status='true'
        date -=1
      end
    end

    #&& user.last.created_on.to_date < (deadline_date-1)
    if expire_time > current_time
      if !@rec_status.present? && !lock_status.present?
        return true
      elsif !@rec_status.present? && lock_status.present?
        #lock_status.delete_all
        return false
      else
        return false
      end
    elsif expire_time <= current_time
      if !@rec_status.present? && !lock_status.present?
        return true
      elsif !@rec_status.present? && lock_status.present? && (lock_status_expire_time.to_date <= expire_time.to_date)

        #lock_status.delete_all
        return true
      else
        #lock_status.delete_all
        return false

      end
    end

  end


  def self.lock_status(user_id)
     lock_status = UserUnlockEntry.where(:user_id=>user_id)
    if lock_status.present?
      return true
    end

  end

def self.dead_line
    array_days = []
    dead_line = (Date.today-1)
    array_size = Setting.plugin_redmine_wktime['wktime_nonlog_day'].to_i
    i = 0
    while i < array_size.to_i do
      if Setting.plugin_redmine_wktime['wktime_public_holiday'].present? && Setting.plugin_redmine_wktime['wktime_public_holiday'].include?(dead_line.to_date.strftime('%Y-%m-%d').to_s) || (dead_line.to_date.wday == 6) || (dead_line.to_date.wday == 0)
        array_size +=1
        dead_line = (dead_line-1)
      else
        array_days << dead_line
        if array_days.size < Setting.plugin_redmine_wktime['wktime_nonlog_day'].to_i
          array_size +=1
          dead_line = (dead_line-1)
        end
      end
      i += 1
    end
    if array_days.present?
      return array_days.last
    end
end

  def self.edit_user(user,entry)
    rec_l1 = Wktime.where(:user_id => entry.user_id,:begin_date => entry.spent_on.to_date,:status => 'l1')
    rec_l2 = Wktime.where(:user_id => entry.user_id,:begin_date => entry.spent_on.to_date, :status => 'l2' )
    if rec_l1.present? || rec_l2.present?
      return true
    else
      return false
    end
  end

end
