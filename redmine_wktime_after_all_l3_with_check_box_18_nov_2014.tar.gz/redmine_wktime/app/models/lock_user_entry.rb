class LockUserEntry < ActiveRecord::Base
  unloadable
end
